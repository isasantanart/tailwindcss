// Animalia Tabs - Simples tabs para produtos de cachorro e gato

document.addEventListener('DOMContentLoaded', function () {
  const tabButtons = document.querySelectorAll('[data-tab]');
  const tabContents = document.querySelectorAll('[data-tab-content]');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      const tab = this.getAttribute('data-tab');
      tabButtons.forEach(b => b.classList.remove('border-emerald-600', 'text-emerald-600', 'bg-white'));
      this.classList.add('border-emerald-600', 'text-emerald-600', 'bg-white');
      tabContents.forEach(c => {
        if (c.getAttribute('data-tab-content') === tab) {
          c.classList.remove('hidden');
        } else {
          c.classList.add('hidden');
        }
      });
    });
  });

  // Ativa a primeira aba por padrão
  if (tabButtons.length > 0) tabButtons[0].click();
});
